document.addEventListener('DOMContentLoaded', () => {
    displayFavorites();
});

function displayFavorites() {
    const favorites = JSON.parse(localStorage.getItem('favoriteFilms')) || [];
    const favoritesList = document.getElementById('favorites-list');
    
    if (favorites.length === 0) {
        favoritesList.innerHTML = "<p>Aucun film ajouté aux favoris.</p>";
        return;
    }
    
    favoritesList.innerHTML = '';

    favorites.forEach(film => {
        const filmElement = document.createElement('div');
        filmElement.classList.add('film-item');
        filmElement.innerHTML = `
            <h3>${film.title}</h3>
            <img src="https://image.tmdb.org/t/p/w200${film.poster}" alt="${film.title}">
            <button class="remove-btn" onclick="removeFromFavorites(${film.id})">Retirer des favoris</button>
        `;
        favoritesList.appendChild(filmElement);
    });
}

function removeFromFavorites(filmId) {
    const favorites = JSON.parse(localStorage.getItem('favoriteFilms')) || [];
    const updatedFavorites = favorites.filter(film => film.id !== filmId);
    
    localStorage.setItem('favoriteFilms', JSON.stringify(updatedFavorites));
    displayFavorites();
}
