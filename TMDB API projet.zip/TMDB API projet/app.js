const apiKey = "ae16ae219de79fbc8c9b3a7535926287";
const apiToken = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJhZTE2YWUyMTlkZTc5ZmJjOGM5YjNhNzUzNTkyNjI4NyIsIm5iZiI6MTcyOTI1ODY3MS4zOTM3NzUsInN1YiI6IjY3MTIxNDcxMWYwZWE0NzE0ZWRiZjFkNCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.tPFkXqF2KWUBT-3IO_oabwHY_-_f4RBkUgea0kW7X1s";

const apiUrl = `https://api.themoviedb.org/3/discover/movie?api_key=${apiKey}&with_genres=27&sort_by=popularity.desc`;

const options = {
  method: 'GET',
  headers: {
    accept: 'application/json',
    Authorization: `Bearer ${apiToken}`
  }
};

fetch(apiUrl, options)
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(err => console.error(err));

document.addEventListener('DOMContentLoaded', () => {
    fetchHalloweenMovies();
});

function fetchHalloweenMovies() {
    fetch(apiUrl, options)
    .then(response => response.json())
    .then(data => {
        const filmsContainer = document.getElementById('films-halloween');
        filmsContainer.innerHTML = '';
        
        data.results.forEach(film => {
            const filmElement = document.createElement('div');
            filmElement.classList.add('film');
            filmElement.innerHTML = `
                <h3>${film.title}</h3>
                <img src="https://image.tmdb.org/t/p/w200${film.poster_path}" alt="${film.title}">
                <span class="star" onclick="addToFavorites(${film.id}, '${film.title}', '${film.poster_path}')">☆</span>
            `;
            filmsContainer.appendChild(filmElement);
        });
    })
    .catch(error => console.error('Error fetching data from TMDB:', error));
}

function addToFavorites(filmId, filmTitle, filmPoster) {
    const favorites = JSON.parse(localStorage.getItem('favoriteFilms')) || [];
    const film = { id: filmId, title: filmTitle, poster: filmPoster };
    
    if (!favorites.some(fav => fav.id === filmId)) {
        favorites.push(film);
        localStorage.setItem('favoriteFilms', JSON.stringify(favorites));
        alert(`${filmTitle} a été ajouté à vos favoris !`);
        console.log("Films favoris après ajout : ", favorites);
    } else {
        alert(`${filmTitle} est déjà dans vos favoris.`);
    }
}
